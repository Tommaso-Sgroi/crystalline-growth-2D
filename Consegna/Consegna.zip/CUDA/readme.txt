Per buildare e runnare i test lanciare gli scripts dalla directory corrente.

Gli argv del programma sono in ordine:
	- lunghezza x
	- lunghezza y
	- numero iterazioni
	- numero particelle
	- posizione seed x
	- posizione seed y
	- scrivi file output [0, 1]
